import { menuItems, restaurantInfo } from '../../data/menu';
import { UtensilsCrossed, Clock, Leaf, Star } from 'lucide-react';

export default function MenuPreview() {
  const categories = ['Appetizers', 'Salads', 'Mains', 'Sides', 'Desserts', 'Beverages'];
  
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 h-full overflow-y-auto">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <UtensilsCrossed className="w-5 h-5 text-emerald-600" />
          <h2 className="text-xl font-bold text-gray-900">{restaurantInfo.name}</h2>
        </div>
        <p className="text-xs text-gray-600 mb-3">{restaurantInfo.description}</p>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Clock className="w-3 h-3" />
          <span className="text-[10px]">Mon-Thu 5-10PM • Fri 5-11PM • Sat 4-11PM • Sun 4-9PM</span>
        </div>
      </div>
      
      <div className="space-y-5">
        {categories.map(category => {
          const items = menuItems.filter(item => item.category === category);
          if (items.length === 0) return null;
          
          return (
            <div key={category}>
              <h3 className="text-sm font-semibold text-gray-900 mb-2 pb-1 border-b border-gray-200 flex items-center gap-2">
                {category}
                <span className="text-[10px] font-normal text-gray-500">({items.length})</span>
              </h3>
              <div className="space-y-2">
                {items.map(item => (
                  <div key={item.id} className="group">
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-medium text-gray-900 group-hover:text-emerald-600 transition-colors text-sm truncate">
                            {item.name}
                          </h4>
                          {item.popular && (
                            <Star className="w-3 h-3 text-amber-500 fill-amber-500 flex-shrink-0" />
                          )}
                          {item.dietary?.includes('vegetarian') && (
                            <Leaf className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                          )}
                          {item.dietary?.includes('vegan') && (
                            <Leaf className="w-3 h-3 text-green-600 flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{item.description}</p>
                      </div>
                      <span className="font-semibold text-gray-900 text-xs whitespace-nowrap">${item.price}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="flex items-center gap-3 text-[10px] text-gray-500">
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-amber-500" />
            <span>Popular</span>
          </div>
          <div className="flex items-center gap-1">
            <Leaf className="w-3 h-3 text-emerald-600" />
            <span>Vegetarian</span>
          </div>
          <div className="flex items-center gap-1">
            <Leaf className="w-3 h-3 text-green-600" />
            <span>Vegan</span>
          </div>
        </div>
      </div>
    </div>
  );
}
