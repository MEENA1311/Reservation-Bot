import { useState, useEffect } from 'react';
import { Calendar, Clock, Users, Mail, Phone, CheckCircle2 } from 'lucide-react';

interface Reservation {
  id: number;
  guest_name: string;
  guest_email: string | null;
  guest_phone: string | null;
  reservation_date: string;
  reservation_time: string;
  party_size: number;
  special_requests: string | null;
  status: string;
  created_at: string;
}

export default function ReservationPanel() {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchReservations = async () => {
    if (!email) return;
    
    setLoading(true);
    try {
      const response = await fetch(`/api/reservations?email=${encodeURIComponent(email)}`);
      const data = await response.json();
      setReservations(data.reservations || []);
    } catch (error) {
      console.error('Failed to fetch reservations:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (email.includes('@')) {
      const timer = setTimeout(fetchReservations, 500);
      return () => clearTimeout(timer);
    }
  }, [email]);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-4">My Reservations</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Enter your email to view reservations
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="your@email.com"
          className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent text-sm"
        />
      </div>

      {loading && (
        <div className="text-center py-8 text-gray-500 text-sm">
          Loading reservations...
        </div>
      )}

      {!loading && email.includes('@') && reservations.length === 0 && (
        <div className="text-center py-8 text-gray-500 text-sm">
          No reservations found for this email.
        </div>
      )}

      {!loading && reservations.length > 0 && (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {reservations.map((reservation) => (
            <div key={reservation.id} className="p-4 rounded-xl border border-gray-200 bg-gradient-to-br from-gray-50 to-white hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900">{reservation.guest_name}</h3>
                  <div className="flex items-center gap-1 mt-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span className="text-xs text-emerald-600 font-medium capitalize">{reservation.status}</span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span>{formatDate(reservation.reservation_date)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span>{formatTime(reservation.reservation_time)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gray-400" />
                  <span>{reservation.party_size} {reservation.party_size === 1 ? 'guest' : 'guests'}</span>
                </div>
                {reservation.guest_email && (
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-gray-400" />
                    <span className="text-xs">{reservation.guest_email}</span>
                  </div>
                )}
                {reservation.guest_phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span className="text-xs">{reservation.guest_phone}</span>
                  </div>
                )}
                {reservation.special_requests && (
                  <div className="mt-2 pt-2 border-t border-gray-200">
                    <p className="text-xs text-gray-500 italic">{reservation.special_requests}</p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
