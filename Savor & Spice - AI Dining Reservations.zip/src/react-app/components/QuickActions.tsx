import { Calendar, UtensilsCrossed, Clock, Users } from 'lucide-react';

interface QuickActionsProps {
  onActionClick: (message: string) => void;
}

export default function QuickActions({ onActionClick }: QuickActionsProps) {
  const actions = [
    {
      icon: Calendar,
      label: "Make a Reservation",
      message: "I'd like to make a reservation",
      color: "from-violet-500 to-purple-600"
    },
    {
      icon: UtensilsCrossed,
      label: "View Menu",
      message: "Can you tell me about your menu?",
      color: "from-emerald-500 to-teal-600"
    },
    {
      icon: Clock,
      label: "Hours & Location",
      message: "What are your hours?",
      color: "from-amber-500 to-orange-600"
    },
    {
      icon: Users,
      label: "Group Dining",
      message: "I need to book for a large group",
      color: "from-blue-500 to-cyan-600"
    }
  ];

  return (
    <div className="grid grid-cols-2 gap-3">
      {actions.map((action, index) => {
        const Icon = action.icon;
        return (
          <button
            key={index}
            onClick={() => onActionClick(action.message)}
            className={`group p-4 rounded-xl bg-gradient-to-br ${action.color} text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 active:scale-95 flex flex-col items-center gap-2`}
          >
            <Icon className="w-6 h-6" />
            <span className="text-xs font-medium text-center">{action.label}</span>
          </button>
        );
      })}
    </div>
  );
}
