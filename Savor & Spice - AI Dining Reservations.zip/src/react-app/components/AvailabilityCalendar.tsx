import { useState, useEffect } from 'react';
import { Calendar, Clock, Users, ChevronLeft, ChevronRight } from 'lucide-react';

interface TimeSlot {
  time: string;
  available: number;
  isAvailable: boolean;
}

export default function AvailabilityCalendar() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  useEffect(() => {
    fetchAvailability(selectedDate);
  }, [selectedDate]);

  const fetchAvailability = async (date: Date) => {
    setLoading(true);
    try {
      const dateStr = date.toISOString().split('T')[0];
      const response = await fetch(`/api/availability?date=${dateStr}`);
      const data = await response.json();
      setTimeSlots(data.slots || []);
    } catch (error) {
      console.error('Failed to fetch availability:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (timeStr: string) => {
    const [hours, minutes] = timeStr.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days: (Date | null)[] = [];
    
    // Add empty cells for days before the month starts
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days in the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const days = getDaysInMonth(currentMonth);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isSameDay = (date1: Date, date2: Date) => {
    return date1.toDateString() === date2.toDateString();
  };

  const isPastDate = (date: Date) => {
    return date < today;
  };

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const monthName = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-emerald-600" />
        <h2 className="text-lg font-bold text-gray-900">Check Availability</h2>
      </div>

      {/* Month Navigation */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={previousMonth}
          className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h3 className="font-semibold text-gray-900">{monthName}</h3>
        <button
          onClick={nextMonth}
          className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
        >
          <ChevronRight className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1 mb-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
            {day}
          </div>
        ))}
        {days.map((day, index) => {
          if (!day) {
            return <div key={`empty-${index}`} className="aspect-square" />;
          }
          
          const isSelected = isSameDay(day, selectedDate);
          const isToday = isSameDay(day, today);
          const isPast = isPastDate(day);
          
          return (
            <button
              key={index}
              onClick={() => !isPast && setSelectedDate(day)}
              disabled={isPast}
              className={`
                aspect-square rounded-lg text-sm font-medium transition-all
                ${isPast ? 'text-gray-300 cursor-not-allowed' : 'hover:bg-emerald-50 cursor-pointer'}
                ${isSelected ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg' : ''}
                ${isToday && !isSelected ? 'border-2 border-emerald-500 text-emerald-600' : ''}
                ${!isSelected && !isToday && !isPast ? 'text-gray-700' : ''}
              `}
            >
              {day.getDate()}
            </button>
          );
        })}
      </div>

      {/* Selected Date */}
      <div className="mb-4 p-3 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg border border-emerald-100">
        <div className="text-sm font-medium text-gray-700 mb-1">Selected Date</div>
        <div className="text-lg font-bold text-emerald-700">
          {selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </div>
      </div>

      {/* Time Slots */}
      {loading ? (
        <div className="text-center py-8 text-gray-500 text-sm">
          Loading availability...
        </div>
      ) : timeSlots.length > 0 ? (
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4 text-gray-600" />
            <h3 className="font-semibold text-gray-900 text-sm">Available Times</h3>
          </div>
          <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
            {timeSlots.map((slot, index) => (
              <div
                key={index}
                className={`
                  p-3 rounded-lg border text-sm transition-all
                  ${slot.isAvailable 
                    ? 'border-emerald-200 bg-emerald-50 hover:bg-emerald-100 cursor-pointer' 
                    : 'border-gray-200 bg-gray-50 opacity-50 cursor-not-allowed'}
                `}
              >
                <div className="font-semibold text-gray-900">{formatTime(slot.time)}</div>
                <div className="flex items-center gap-1 mt-1 text-xs text-gray-600">
                  <Users className="w-3 h-3" />
                  <span>{slot.available} seats</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500 text-sm">
          Select a date to view availability
        </div>
      )}
    </div>
  );
}
