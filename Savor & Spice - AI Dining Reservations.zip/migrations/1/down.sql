
DROP INDEX idx_reservations_email;
DROP INDEX idx_reservations_date;
DROP TABLE reservations;
